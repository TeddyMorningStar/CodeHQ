CREATE
DATABASE `codeHQAugen`;
USE
`codeHQAugen`;
DROP TABLE IF EXISTS `attribute`;
DROP TABLE IF EXISTS `device_data`;
DROP TABLE IF EXISTS `device_location`;
DROP TABLE IF EXISTS `device`;
CREATE TABLE `device`
(
    `id`        int(11) NOT NULL AUTO_INCREMENT,
    `device_id` varchar(25) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
    `created`   timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    `modified`  timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `device_id` (`device_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Device information';
CREATE TABLE `device_location`
(
    `id`        int(11) NOT NULL AUTO_INCREMENT,
    `device_id` int(11) NOT NULL,
    `latitude`  float(11, 7
) NOT NULL,
  `longitude` float(11,7) NOT NULL,
  `created` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `DEVICE_LOCATION_DEVICE_ID` (`device_id`),
  CONSTRAINT `DEVICE_LOCATION_DEVICE_ID` FOREIGN KEY (`device_id`) REFERENCES `device` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Device location';
CREATE TABLE `device_data`
(
    `id`        int(11) NOT NULL AUTO_INCREMENT,
    `device_id` int(11) NOT NULL,
    `created`   timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    `modified`  timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY         `DEVICE_DATA_DEVICE_ID` (`device_id`),
    CONSTRAINT `DEVICE_DATA_DEVICE_ID` FOREIGN KEY (`device_id`) REFERENCES `device` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Device data';
CREATE TABLE `attribute`
(
    `id`      int(11) NOT NULL AUTO_INCREMENT,
    `label`   varchar(255) NOT NULL,
    `value`   text CHARACTER SET utf8 COLLATE utf8_general_ci,
    `type`    varchar(255) NOT NULL,
    `parent`  int(11) DEFAULT NULL,
    `data_id` int(11) NOT NULL,
    PRIMARY KEY (`id`),
    KEY       `ATTRIBUTE_DATA_ID` (`data_id`),
    CONSTRAINT `ATTRIBUTE_DATA_ID` FOREIGN KEY (`data_id`) REFERENCES `device_data` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Dat attribute';