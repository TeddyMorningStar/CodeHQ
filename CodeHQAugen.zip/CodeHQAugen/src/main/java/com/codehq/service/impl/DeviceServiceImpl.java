package com.codehq.service.impl;

import com.codehq.entity.Device;
import com.codehq.entity.DeviceData;
import com.codehq.entity.DeviceLocation;
import com.codehq.model.DeviceResource;
import com.codehq.model.request.DeviceRequest;
import com.codehq.repository.DeviceRepository;
import com.codehq.service.DeviceDataService;
import com.codehq.service.DeviceLocationService;
import com.codehq.service.DeviceService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Service
@Transactional
public class DeviceServiceImpl implements DeviceService {
    private final Logger LOGGER = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private DeviceRepository repository;

    @Autowired
    private DeviceDataService deviceDataService;

    @Autowired
    private DeviceLocationService deviceLocationService;

    @Override
    public List<DeviceResource> getDevices() {
        List<DeviceResource> results = new ArrayList<>();
        try {
            Iterable<Device> devices = this.repository.findAll();
            devices.forEach(device -> results.add(DeviceResource.fromDevice(device)));
        } catch (Exception ex) {
            LOGGER.error("Get device list error: {}", ex.getMessage());
            ex.printStackTrace();
        }
        return results;
    }

    @Override
    public DeviceResource getByDeviceId(String deviceId) {
        LOGGER.info("Get device info by deviceId: {}", deviceId);
        try {
            Device device = getDeviceByDeviceId(deviceId);
            return Objects.nonNull(device) ? DeviceResource.fromDevice(device) : null;
        } catch (Exception ex) {
            LOGGER.error("Get device info by deviceId: {}, error: {}", deviceId, ex.getMessage());
            ex.printStackTrace();
        }
        return null;
    }

    /**
     * Get device by device id
     *
     * @param deviceId
     * @return {@link Device}
     */
    private Device getDeviceByDeviceId(String deviceId) {
        return this.repository.findDeviceByDeviceId(deviceId);
    }

    /**
     * Save device.
     *
     * @param device
     * @return {@link Device}
     */
    private Device save(Device device) {
        return this.repository.save(device);
    }

    /**
     * Update device.
     *
     * @param device
     * @return {@link Device}
     */
    private Device update(Device device) {
        this.repository.update(device.getId(), device.getDeviceId(), device.getModified());
        return device;
    }

    /**
     * Update or save device.
     *
     * @param device
     * @return {@link Device}
     */
    private Device updateOrSave(Device device) {
        Device existed = getDeviceByDeviceId(device.getDeviceId());
        if (Objects.nonNull(existed)) {
            // Update device
            existed.setDeviceId(device.getDeviceId());
            existed.setModified(LocalDateTime.now());
            update(existed);

            // Update location
            List<DeviceLocation> locations = this.deviceLocationService.save(device.getLocations().stream().map(location -> {
                location.setDevice(existed);
                return location;
            }).collect(Collectors.toList()));
            existed.setLocations(locations);

            // Update data
            List<DeviceData> dataList = this.deviceDataService.save(device.getData().stream().map(data -> {
                data.setDevice(existed);
                return data;
            }).collect(Collectors.toList()));
            existed.setData(dataList);

            return existed;
        }
        return save(device);
    }

    @Override
    public DeviceResource store(DeviceRequest request) {
        LOGGER.info("Store device request: {}", request);
        try {
            updateOrSave(request.toDevice());
            return getByDeviceId(request.getDeviceId());
        } catch (Exception ex) {
            LOGGER.error("Store device request: {}, error: {}", request, ex.getMessage());
            ex.printStackTrace();
        }
        return null;
    }
}
