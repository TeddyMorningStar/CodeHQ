package com.codehq.service;

import com.codehq.model.DeviceResource;
import com.codehq.model.request.DeviceRequest;

import java.util.List;

public interface DeviceService {

    /**
     * Get device list.
     *
     * @return {@link List} of {@link DeviceResource}
     */
    List<DeviceResource> getDevices();

    /**
     * Get device info by deviceId
     *
     * @param deviceId
     * @return {@link DeviceResource}
     */
    DeviceResource getByDeviceId(String deviceId);

    /**
     * Store device.
     *
     * @param request
     * @return {@link DeviceResource}
     */
    DeviceResource store(DeviceRequest request);
}
