package com.codehq.service.impl;

import com.codehq.entity.DeviceLocation;
import com.codehq.repository.DeviceLocationRepository;
import com.codehq.service.DeviceLocationService;
import org.apache.commons.collections4.IterableUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;

@Service
@Transactional
public class DeviceLocationServiceImpl implements DeviceLocationService {
    @Autowired
    private DeviceLocationRepository repository;

    @Override
    public DeviceLocation save(DeviceLocation location) {
        return this.repository.save(location);
    }

    @Override
    public List<DeviceLocation> save(List<DeviceLocation> locations) {
        Iterable<DeviceLocation> results = this.repository.saveAll(locations);
        return IterableUtils.toList(results);
    }
}
