package com.codehq.service.impl;

import com.codehq.entity.DeviceData;
import com.codehq.repository.DeviceDataRepository;
import com.codehq.service.DeviceDataService;
import org.apache.commons.collections4.IterableUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;

@Service
@Transactional
public class DeviceDataServiceImpl implements DeviceDataService {
    @Autowired
    private DeviceDataRepository repository;

    @Override
    public DeviceData save(DeviceData data) {
        return this.repository.save(data);
    }

    @Override
    public List<DeviceData> save(List<DeviceData> dataList) {
        Iterable<DeviceData> results = this.repository.saveAll(dataList);
        return IterableUtils.toList(results);
    }
}
