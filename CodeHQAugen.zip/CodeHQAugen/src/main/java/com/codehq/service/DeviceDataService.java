package com.codehq.service;

import com.codehq.entity.DeviceData;

import java.util.List;

public interface DeviceDataService {
    /**
     * Save device data.
     *
     * @param data
     * @return {@link DeviceData}
     */
    DeviceData save(DeviceData data);

    /**
     * Save device data list.
     *
     * @param dataList
     * @return {@link List} of {@link DeviceData}
     */
    List<DeviceData> save(List<DeviceData> dataList);
}
