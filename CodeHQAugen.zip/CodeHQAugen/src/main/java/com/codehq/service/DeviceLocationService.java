package com.codehq.service;

import com.codehq.entity.DeviceLocation;

import java.util.List;

public interface DeviceLocationService {
    /**
     * Save device location.
     *
     * @param location
     * @return {@link DeviceLocation}
     */
    DeviceLocation save(DeviceLocation location);

    /**
     * Save device location list.
     *
     * @param locations
     * @return {@link List} of {@link DeviceLocation}
     */
    List<DeviceLocation> save(List<DeviceLocation> locations);
}
