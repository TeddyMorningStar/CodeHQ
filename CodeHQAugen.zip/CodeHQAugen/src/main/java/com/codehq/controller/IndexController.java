package com.codehq.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

@RestController
public class IndexController extends BaseController {
    private final Logger LOGGER = LoggerFactory.getLogger(this.getClass());

    /**
     * Ping action.
     *
     * @return {@link ResponseEntity}
     */
    @GetMapping("/api/ping")
    public ResponseEntity<?> ping() {
        String requestId = getRequestId();
        LOGGER.info("START RequestId: {} Get ping action.", requestId);
        Map<String, String> result = new HashMap<>();
        result.put("pong", "Pong!");
        LOGGER.info("END RequestId: {} Get ping action.", requestId);
        return ResponseEntity.ok().body(result);
    }
}