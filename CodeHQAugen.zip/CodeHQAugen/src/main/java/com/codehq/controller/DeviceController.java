package com.codehq.controller;

import com.codehq.model.DeviceResource;
import com.codehq.model.request.DeviceRequest;
import com.codehq.model.response.EmptyData;
import com.codehq.service.DeviceService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;
import java.util.Objects;

@RestController
public class DeviceController extends BaseController {
    private final Logger LOGGER = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private DeviceService deviceService;

    /**
     * Get device list.
     *
     * @return {@link ResponseEntity}
     */
    @GetMapping("/api/devices")
    public ResponseEntity<?> getDevices() {
        String requestId = getRequestId();
        LOGGER.info("START RequestId: {} Get device list.", requestId);
        List<DeviceResource> results = this.deviceService.getDevices();
        LOGGER.info("END RequestId: {} Get device list.", requestId);
        return ResponseEntity.ok().body(results);
    }

    /**
     * Get device by deviceId.
     *
     * @param deviceId
     * @return {@link ResponseEntity}
     */
    @GetMapping("/api/devices/{deviceId}")
    public ResponseEntity<?> getDevice(@PathVariable(value = "deviceId") String deviceId) {
        String requestId = getRequestId();
        LOGGER.info("START RequestId: {} Get device by deviceId: {}.", requestId, deviceId);
        DeviceResource result = this.deviceService.getByDeviceId(deviceId);
        LOGGER.info("END RequestId: {} Get device by deviceId: {}.", requestId, deviceId);
        return ResponseEntity.ok().body(result);
    }

    /**
     * Save device.
     *
     * @return {@link ResponseEntity}
     * @oaram request
     */
    @PostMapping("/api/devices")
    public ResponseEntity<?> store(@Valid @RequestBody DeviceRequest request) {
        String requestId = getRequestId();
        LOGGER.info("START RequestId: {} Stored device request: {}.", requestId, request);
        DeviceResource result = this.deviceService.store(request);
        LOGGER.info("END RequestId: {} Stored device request: {}.", requestId, request);
        return Objects.nonNull(result) ? ResponseEntity.ok().body(result) : ResponseEntity.status(HttpStatus.NO_CONTENT).body(new EmptyData());
    }
}
