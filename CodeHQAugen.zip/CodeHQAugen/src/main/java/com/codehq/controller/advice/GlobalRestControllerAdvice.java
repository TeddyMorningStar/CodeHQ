package com.codehq.controller.advice;

import com.codehq.model.response.ResponseData;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.http.converter.HttpMessageNotWritableException;
import org.springframework.lang.Nullable;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingPathVariableException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.context.request.ServletWebRequest;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.NoHandlerFoundException;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import java.util.*;

@ControllerAdvice
public class GlobalRestControllerAdvice extends ResponseEntityExceptionHandler {
    private static final Logger LOGGER = LoggerFactory.getLogger(GlobalRestControllerAdvice.class);
    private static final String SERVER_ERROR_MESSAGE = "Server error occurred. Please contact to admin.";
    private static final String NOT_READABLE_MESSAGE = "Required request body is missing.";
    private static final String NOT_WRITABLE_MESSAGE = "Error writing JSON output.";
    private static final String NO_HANDLER_FOUND_MESSAGE = "Could not find the %s method for URL %s";
    private static final String VALIDATION_ERROR_MESSAGE = "Validation error";

    @Override
    protected ResponseEntity<Object> handleMissingServletRequestParameter(MissingServletRequestParameterException ex, HttpHeaders headers, HttpStatus status, WebRequest request) {
        ServletWebRequest servletWebRequest = (ServletWebRequest) request;
        String message = "MissingServletRequestParameterException method: " + servletWebRequest.getHttpMethod() + ", path: " + servletWebRequest.getRequest().getServletPath() + ", error: {}" + ex.getMessage();
        LOGGER.error(message);
        return new ResponseEntity<Object>(ResponseData.buildException(status, message), status);
    }

    @Override
    protected ResponseEntity<Object> handleHttpMediaTypeNotSupported(HttpMediaTypeNotSupportedException ex, HttpHeaders headers, HttpStatus status, WebRequest request) {
        ServletWebRequest servletWebRequest = (ServletWebRequest) request;
        LOGGER.error("HttpMediaTypeNotSupportedException method: {}, path: {}, error message: {}", servletWebRequest.getHttpMethod(), servletWebRequest.getRequest().getServletPath(), ex.getMessage());
        StringBuilder message = new StringBuilder();
        message.append(ex.getContentType());
        message.append("Media type is not supported. Supported media types are ");
        ex.getSupportedMediaTypes().forEach(t -> message.append(t).append(", "));
        return new ResponseEntity<Object>(ResponseData.buildException(status, message.toString()), status);
    }

    @Override
    protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex, HttpHeaders headers, HttpStatus status, WebRequest request) {
        ServletWebRequest servletWebRequest = (ServletWebRequest) request;
        LOGGER.error("MethodArgumentNotValidException method: {}, path: {}, error message: {}", servletWebRequest.getHttpMethod(), servletWebRequest.getRequest().getServletPath(), ex.getMessage());
        final Map<String, String> errors = new HashMap<>();
        for (final FieldError error : ex.getBindingResult().getFieldErrors()) {
            errors.put(error.getField(), error.getDefaultMessage());
        }
        for (final ObjectError error : ex.getBindingResult().getGlobalErrors()) {
            errors.put(error.getObjectName(), error.getDefaultMessage());
        }
        return new ResponseEntity<Object>(ResponseData.buildValidation(status, VALIDATION_ERROR_MESSAGE, errors), status);
    }

    @Override
    protected ResponseEntity<Object> handleHttpMessageNotReadable(HttpMessageNotReadableException ex, HttpHeaders headers, HttpStatus status, WebRequest request) {
        ServletWebRequest servletWebRequest = (ServletWebRequest) request;
        LOGGER.error("HttpMessageNotReadableException method: {}, path: {}, error message: {}", servletWebRequest.getHttpMethod(), servletWebRequest.getRequest().getServletPath(), ex.getMessage());
        return new ResponseEntity<Object>(ResponseData.buildException(status, NOT_READABLE_MESSAGE), status);
    }

    @Override
    protected ResponseEntity<Object> handleHttpMessageNotWritable(HttpMessageNotWritableException ex, HttpHeaders headers, HttpStatus status, WebRequest request) {
        ServletWebRequest servletWebRequest = (ServletWebRequest) request;
        LOGGER.error("HttpMessageNotWritableException method: {}, path: {}, error message: {}", servletWebRequest.getHttpMethod(), servletWebRequest.getRequest().getServletPath(), ex);
        return new ResponseEntity<Object>(ResponseData.buildException(status, NOT_WRITABLE_MESSAGE), status);
    }

    @Override
    protected ResponseEntity<Object> handleNoHandlerFoundException(NoHandlerFoundException ex, HttpHeaders headers, HttpStatus status, WebRequest request) {
        ServletWebRequest servletWebRequest = (ServletWebRequest) request;
        LOGGER.error("NoHandlerFoundException method {}, path: {}, error message: {}", servletWebRequest.getHttpMethod(), servletWebRequest.getRequest().getServletPath(), ex);
        String message = String.format(NO_HANDLER_FOUND_MESSAGE, ex.getHttpMethod(), ex.getRequestURL());
        return new ResponseEntity<Object>(ResponseData.buildException(status, message), status);
    }

    @Override
    protected ResponseEntity<Object> handleMissingPathVariable(MissingPathVariableException ex, HttpHeaders headers, HttpStatus status, WebRequest request) {
        ServletWebRequest servletWebRequest = (ServletWebRequest) request;
        LOGGER.error("MissingPathVariableException method: {}, path: {}, error message: {}", servletWebRequest.getHttpMethod(), servletWebRequest.getRequest().getServletPath(), ex);
        return new ResponseEntity<Object>(ResponseData.buildException(status, ex.getMessage()), status);
    }

    @Override
    protected ResponseEntity<Object> handleExceptionInternal(Exception ex, @Nullable Object body, HttpHeaders headers, HttpStatus status, WebRequest request) {
        ServletWebRequest servletWebRequest = (ServletWebRequest) request;
        LOGGER.error("ExceptionInternal method: {}, path: {}, error message: {}", servletWebRequest.getHttpMethod(), servletWebRequest.getRequest().getServletPath(), ex);
        return new ResponseEntity<Object>(ResponseData.buildException(status, SERVER_ERROR_MESSAGE), status);
    }
}
