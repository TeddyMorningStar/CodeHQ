package com.codehq.controller;

import java.util.UUID;

public abstract class BaseController {
    /**
     * Get request id.
     *
     * @return {@link String}
     */
    protected String getRequestId() {
        return UUID.randomUUID().toString();
    }
}
