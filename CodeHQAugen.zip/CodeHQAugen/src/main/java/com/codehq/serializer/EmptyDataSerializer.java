package com.codehq.serializer;

import com.codehq.model.response.EmptyData;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.ser.std.StdSerializer;

import java.io.IOException;

public class EmptyDataSerializer extends StdSerializer<EmptyData> {
    private static final long serialVersionUID = -3765573465196874288L;

    public EmptyDataSerializer() {
        this(EmptyData.class);
    }

    public EmptyDataSerializer(Class<EmptyData> type) {
        super(type);
    }

    @Override
    public void serialize(EmptyData value, JsonGenerator gen, SerializerProvider provider) throws IOException {
        gen.writeStartObject();
        gen.writeEndObject();
    }
}
