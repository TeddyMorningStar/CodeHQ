package com.codehq.util;

import com.codehq.common.AttributeType;
import org.apache.commons.lang3.StringUtils;

import java.util.Objects;

public class ConvertType {
    public static Object convertPrimitive(Object value, AttributeType attributeType) {
        try {
            if (Objects.nonNull(value)) {
                if (StringUtils.equalsIgnoreCase(attributeType.getType(), Integer.class.getSimpleName())) {
                    return Integer.parseInt(value.toString());
                }
                if (StringUtils.equalsIgnoreCase(attributeType.getType(), Double.class.getSimpleName())) {
                    return Double.parseDouble(value.toString());
                }
                if (StringUtils.equalsIgnoreCase(attributeType.getType(), Boolean.class.getSimpleName())) {
                    return Boolean.parseBoolean(value.toString());
                }
            }
        } catch (Exception ex) {
            System.out.println("Get type: " + attributeType.getType() + ", error: " + ex.getMessage());
            ex.printStackTrace();
        }
        return value;
    }
}
