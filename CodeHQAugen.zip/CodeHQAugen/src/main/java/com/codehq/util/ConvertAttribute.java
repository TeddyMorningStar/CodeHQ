package com.codehq.util;

import com.codehq.common.AttributeType;
import com.codehq.entity.Attribute;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jdk8.Jdk8Module;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import org.apache.commons.lang3.StringUtils;

import java.util.*;

public class ConvertAttribute {
    public static final ObjectMapper OBJECT_MAPPER = new ObjectMapper()
            .configure(JsonParser.Feature.ALLOW_UNQUOTED_FIELD_NAMES, true)
            .registerModule(new Jdk8Module()).registerModule(new JavaTimeModule())
            .disable(SerializationFeature.FAIL_ON_EMPTY_BEANS, SerializationFeature.WRITE_DATES_AS_TIMESTAMPS)
            .disable(DeserializationFeature.ADJUST_DATES_TO_CONTEXT_TIME_ZONE);

    public static void createDeviceAttributes(Map<String, Object> data, Set<Attribute> attributes) {
        for (Map.Entry<String, Object> entry : data.entrySet()) {
            if (entry.getValue() instanceof HashMap) {
                attributes.add(getAttributeMap(entry));
            } else if (entry.getValue() instanceof List) {
                attributes.add(getAttributeList(entry));
            } else {
                attributes.add(getAttributePrimitive(entry));
            }
        }
    }

    public static String toJson(Object obj) {
        try {
            return Objects.nonNull(obj) ? OBJECT_MAPPER.writeValueAsString(obj) : StringUtils.EMPTY;
        } catch (Exception e) {
            System.out.println("Error while converting obj to json error: " + e.getMessage());
        }
        return StringUtils.EMPTY;
    }

    public static Attribute getAttributeMap(Map.Entry<String, Object> entry) {
        return Attribute.builder()
                .type(AttributeType.MAP.getType())
                .label(entry.getKey())
                .value(toJson(entry.getValue()))
                .build();
    }

    public static Attribute getAttributeList(Map.Entry<String, Object> entry) {
        return Attribute.builder()
                .type(AttributeType.LIST.getType())
                .label(entry.getKey())
                .value(toJson(entry.getValue()))
                .build();
    }

    public static Attribute getAttributePrimitive(Map.Entry<String, Object> entry) {
        Attribute attribute = Attribute.builder()
                .label(entry.getKey())
                .value(entry.getValue().toString())
                .type(AttributeType.STRING.getType())
                .build();
        try {
            if (Objects.nonNull(getValueInteger(entry.getValue().toString()))) {
                attribute.setType(AttributeType.INTEGER.getType());
                return attribute;
            }
            if (Objects.nonNull(getValueDouble(entry.getValue().toString()))) {
                attribute.setType(AttributeType.DOUBLE.getType());
                return attribute;
            }
            if (Objects.nonNull(getValueBoolean(entry.getValue().toString()))) {
                attribute.setType(AttributeType.BOOLEAN.getType());
                return attribute;
            }
        } catch (Exception ex) {
            System.out.println("Error while getting primitive value: " + ex.getMessage());
        }
        return attribute;
    }

    public static Integer getValueInteger(String value) {
        try {
            return Integer.parseInt(value);
        } catch(NumberFormatException ex) {
            System.out.println("Error while getting int value: " + ex.getMessage());
        }
        return null;
    }

    public static Double getValueDouble(String value) {
        try {
            return Double.parseDouble(value);
        } catch(NumberFormatException ex) {
            System.out.println("Error while getting double value: " + ex.getMessage());
        }
        return null;
    }

    public static Boolean getValueBoolean(String value) {
        try {
            return Boolean.parseBoolean(value);
        } catch(NumberFormatException ex) {
            System.out.println("Error while getting double value: " + ex.getMessage());
        }
        return null;
    }
}
