package com.codehq.common;

public enum Code {
    // Define application code.
    // Success
    SUCCESS(0),
    ;

    private int value;

    Code(int value) {
        setValue(value);
    }

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }
}
