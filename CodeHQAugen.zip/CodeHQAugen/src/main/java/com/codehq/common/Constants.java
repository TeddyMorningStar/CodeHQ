package com.codehq.common;

public class Constants {
    public static final String TIMESTAMP = "timestamp";
}
