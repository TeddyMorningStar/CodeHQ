package com.codehq.common;

import org.apache.commons.lang3.StringUtils;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

public enum AttributeType {
    INTEGER(Integer.class.getSimpleName(), Integer.class.getName()),
    MAP(Map.class.getSimpleName(), Map.class.getName()),
    STRING(String.class.getSimpleName(), String.class.getName()),
    DOUBLE(Double.class.getSimpleName(), Double.class.getName()),
    LIST(List.class.getSimpleName(), List.class.getName()),
    BOOLEAN(Boolean.class.getSimpleName(), Boolean.class.getName());

    private String type;
    private String clazz;

    AttributeType(String value, String clazz) {
        setType(value);
        setClazz(clazz);
    }

    public static AttributeType fromType(String type) {
        return Arrays.asList(values()).stream().filter(item -> StringUtils.equalsIgnoreCase(item.getType(), type))
                .findFirst()
                .orElse(MAP);
    }

    public static AttributeType fromClazz(String clazz) {
        return Arrays.asList(values()).stream().filter(item -> StringUtils.equalsIgnoreCase(item.getClazz(), clazz))
                .findFirst()
                .orElse(STRING);
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getClazz() {
        return clazz;
    }

    public void setClazz(String clazz) {
        this.clazz = clazz;
    }
}
