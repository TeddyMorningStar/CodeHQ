package com.codehq.entity;

import lombok.*;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.List;

@Entity
@Getter
@Setter
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "device")
public class Device {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "device_id")
    private String deviceId;

    private LocalDateTime created;

    private LocalDateTime modified;

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "device")
    @EqualsAndHashCode.Exclude
    @ToString.Exclude
    private List<DeviceLocation> locations;

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "device")
    @EqualsAndHashCode.Exclude
    @ToString.Exclude
    private List<DeviceData> data;
}
