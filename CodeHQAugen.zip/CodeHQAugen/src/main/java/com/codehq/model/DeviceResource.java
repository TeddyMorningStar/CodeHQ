package com.codehq.model;

import com.codehq.common.AttributeType;
import com.codehq.common.Constants;
import com.codehq.entity.Attribute;
import com.codehq.entity.Device;
import com.codehq.entity.DeviceData;
import com.codehq.util.ConvertType;
import com.codehq.util.JsonMapper;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import lombok.*;
import org.apache.commons.collections4.CollectionUtils;

import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

@Getter
@Setter
@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonSerialize
@Builder(setterPrefix = "with", toBuilder = true)
public class DeviceResource {
    private String deviceId;
    private Double latitude;
    private Double longitude;
    private List<Map> data;

    @JsonIgnore
    public static DeviceResource fromDevice(Device device) {
        return DeviceResource.builder()
                .withDeviceId(device.getDeviceId())
                .withLatitude(CollectionUtils.isNotEmpty(device.getLocations()) ? device.getLocations().stream().findFirst().get().getLatitude() : null)
                .withLongitude(CollectionUtils.isNotEmpty(device.getLocations()) ? device.getLocations().stream().findFirst().get().getLongitude() : null)
                .withData(buildDeviceData(device.getData())).build();
    }

    /**
     * Build device data.
     *
     * @param deviceDataList
     * @return {@link List} of {@link Map}
     */
    @JsonIgnore
    private static List<Map> buildDeviceData(List<DeviceData> deviceDataList) {
        if (CollectionUtils.isEmpty(deviceDataList)) {
            return Collections.emptyList();
        }
        List<Map> results = new ArrayList<>();
        deviceDataList.stream().filter(deviceData -> CollectionUtils.isNotEmpty(deviceData.getAttributes())).forEach(deviceData -> {
            Set<Attribute> attributes = deviceData.getAttributes().stream()
                    .filter(attribute -> Objects.isNull(attribute.getParent()))
                    .collect(Collectors.toSet());
            Map<Object, Object> data = iterateAttribute(attributes);
            if (Objects.nonNull(data) && CollectionUtils.isNotEmpty(data.entrySet())) {
                data.put(Constants.TIMESTAMP, deviceData.getModified().format(DateTimeFormatter.ISO_DATE_TIME));
                results.add(data);
            }
        });
        return results;
    }

    /**
     * Interate attribute.
     *
     * @param attributes
     * @return {@link Map}
     */
    @JsonIgnore
    private static Map iterateAttribute(Set<Attribute> attributes) {
        Map<Object, Object> data = new HashMap<>();
        for (Attribute attribute : attributes) {
            Map<Object, Object> dataItem = new HashMap<>();
            AttributeType type = AttributeType.fromType(attribute.getType());
            if (Objects.equals(type, AttributeType.MAP)) {
                dataItem.put(attribute.getLabel(), JsonMapper.fromJson(attribute.getValue(), Map.class));
            } else if (Objects.equals(type, AttributeType.LIST)) {
                dataItem.put(attribute.getLabel(), JsonMapper.readList(attribute.getValue(), Object.class));
            } else {
                dataItem.put(attribute.getLabel(), ConvertType.convertPrimitive(attribute.getValue(), type));
            }
            if (Objects.nonNull(dataItem) && CollectionUtils.isNotEmpty(dataItem.entrySet())) {
                data.putAll(dataItem);
            }
        }
        return data;
    }
}
