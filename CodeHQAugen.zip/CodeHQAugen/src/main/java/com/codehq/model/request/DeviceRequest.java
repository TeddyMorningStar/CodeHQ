package com.codehq.model.request;

import com.codehq.entity.Attribute;
import com.codehq.entity.Device;
import com.codehq.entity.DeviceData;
import com.codehq.entity.DeviceLocation;
import com.codehq.util.ConvertAttribute;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.*;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

@Getter
@Setter
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DeviceRequest {
    @NotEmpty(message = "Device id must be not null.")
    private String deviceId;

    @NotNull(message = "Device latitude must be not null.")
    private Double latitude;

    @NotNull(message = "Device longitude must be not null.")
    private Double longitude;

    @NotNull(message = "Device data must be not null.")
    private Map<String, Object> data;

    @JsonIgnore
    public Device toDevice() {
        Device device = Device.builder()
                .deviceId(getDeviceId())
                .created(LocalDateTime.now())
                .modified(LocalDateTime.now())
                .build();
        device.setLocations(createDeviceLocation(device));
        device.setData(createDeviceData(device));
        return device;
    }

    @JsonIgnore
    public List<DeviceLocation> createDeviceLocation(Device device) {
        return Collections.singletonList(DeviceLocation.builder().device(device).latitude(getLatitude()).longitude(getLongitude()).created(LocalDateTime.now()).build());
    }

    @JsonIgnore
    public List<DeviceData> createDeviceData(Device device) {
        Set<Attribute> attributes = new HashSet<>();
        DeviceData data = DeviceData.builder()
                .created(LocalDateTime.now())
                .modified(LocalDateTime.now())
                .device(device)
                .build();
        ConvertAttribute.createDeviceAttributes(getData(), attributes);
        attributes = attributes.stream().map(attribute -> {
            attribute.setData(data);
            return attribute;
        }).collect(Collectors.toSet());
        data.setAttributes(attributes);
        return Collections.singletonList(data);
    }
}
