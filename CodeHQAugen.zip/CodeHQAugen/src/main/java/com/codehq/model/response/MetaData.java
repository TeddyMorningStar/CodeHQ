package com.codehq.model.response;

import com.codehq.common.Code;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.http.HttpStatus;
import org.springframework.lang.Nullable;

import java.util.Collection;
import java.util.Objects;

@Getter
@Setter
@JsonSerialize
@Builder(setterPrefix = "with", toBuilder = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class MetaData {

    @Nullable
    private String message;

    @Nullable
    private Integer code;

    @Nullable
    private Integer returnedRecords;

    @Nullable
    private Integer totalRecords;

    @Nullable
    private Integer offset;

    public static MetaData buildSuccess() {
        return MetaData.builder()
                .withCode(Code.SUCCESS.getValue())
                .withMessage(Code.SUCCESS.toString())
                .build();
    }

    public static MetaData buildSuccess(String message) {
        return MetaData.builder()
                .withCode(Code.SUCCESS.getValue())
                .withMessage(message)
                .build();
    }

    public static MetaData buildSuccess(Object data) {
        return MetaData.builder()
                .withCode(Code.SUCCESS.getValue())
                .withMessage(Objects.nonNull(data) ? Code.SUCCESS.toString() : HttpStatus.NO_CONTENT.name())
                .build();
    }

    public static MetaData buildSuccess(Object data, String message) {
        return MetaData.builder()
                .withCode(Code.SUCCESS.getValue())
                .withMessage(Objects.nonNull(data) ? message : HttpStatus.NO_CONTENT.name())
                .build();
    }

    public static MetaData buildSuccess(Collection<?> data) {
        return MetaData.builder()
                .withCode(Code.SUCCESS.getValue())
                .withMessage(CollectionUtils.isNotEmpty(data) ? Code.SUCCESS.toString() : HttpStatus.NO_CONTENT.name())
                .withTotalRecords(CollectionUtils.size(data))
                .build();
    }

    public static MetaData buildSuccess(Collection<?> data, String message) {
        return MetaData.builder()
                .withCode(Code.SUCCESS.getValue())
                .withMessage(message)
                .withTotalRecords(CollectionUtils.size(data))
                .build();
    }

    public static MetaData buildException(HttpStatus status) {
        return MetaData.builder()
                .withCode(status.value())
                .withMessage(status.toString())
                .build();
    }

    public static MetaData buildException(HttpStatus status, String message) {
        return MetaData.builder()
                .withCode(status.value())
                .withMessage(message)
                .build();
    }
}
