package com.codehq.model.response;

import com.codehq.serializer.EmptyDataSerializer;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.http.HttpStatus;
import org.springframework.lang.Nullable;

import java.util.Collection;
import java.util.Collections;

@Getter
@Setter
@JsonSerialize
@Builder(setterPrefix = "with", toBuilder = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ResponseData {

    @Nullable
    private MetaData meta;

    @Nullable
    @JsonSerialize(nullsUsing = EmptyDataSerializer.class)
    private Object data;

    /**
     * Build response data object with application Code.SUCCESS.
     *
     * @return {@link ResponseData}
     */
    public static ResponseData buildSuccess() {
        return ResponseData.builder().withData(new EmptyData()).withMeta(MetaData.buildSuccess()).build();
    }

    /**
     * Build response data object with application Code.SUCCESS.
     *
     * @param data
     * @return {@link ResponseData}
     */
    public static ResponseData buildSuccess(Object data) {
        return ResponseData.builder().withData(data).withMeta(MetaData.buildSuccess(data)).build();
    }

    /**
     * Build response data object with application Code.SUCCESS.
     *
     * @param message
     * @return {@link ResponseData}
     */
    public static ResponseData buildSuccess(String message) {
        return ResponseData.builder().withData(new EmptyData()).withMeta(MetaData.buildSuccess(message)).build();
    }

    /**
     * Build response data object application Code.SUCCESS.
     *
     * @param data
     * @param message
     * @return {@link ResponseData}
     */
    public static ResponseData buildSuccess(Object data, String message) {
        return ResponseData.builder().withData(data).withMeta(MetaData.buildSuccess(data, message)).build();
    }

    /**
     * Build response list object with application Code.SUCCESS.
     *
     * @param data
     * @return {@link ResponseData}
     */
    public static ResponseData buildSuccess(Collection<?> data) {
        return ResponseData.builder().withData(CollectionUtils.isNotEmpty(data) ? data : Collections.emptyList())
                .withMeta(MetaData.buildSuccess(data)).build();
    }

    /**
     * Build response list object with application Code.SUCCESS.
     *
     * @param data
     * @param message
     * @return {@link ResponseData}
     */
    public static ResponseData buildSuccess(Collection<?> data, String message) {
        return ResponseData.builder().withData(CollectionUtils.isNotEmpty(data) ? data : Collections.emptyList())
                .withMeta(MetaData.buildSuccess(data)).build();
    }

    /**
     * Build response data object with application Code.SUCCESS.
     *
     * @param status
     * @return {@link ResponseData}
     */
    public static ResponseData buildException(HttpStatus status) {
        return ResponseData.builder().withData(new EmptyData()).withMeta(MetaData.buildException(status)).build();
    }

    /**
     * Build response data object with application Code.SUCCESS.
     *
     * @param status
     * @param message
     * @return {@link ResponseData}
     */
    public static ResponseData buildException(HttpStatus status, String message) {
        return ResponseData.builder().withData(new EmptyData()).withMeta(MetaData.buildException(status, message)).build();
    }

    /**
     * Build response data object with application Code.SUCCESS.
     *
     * @param status
     * @param message
     * @return {@link ResponseData}
     */
    public static ResponseData buildValidation(HttpStatus status, String message, Object data) {
        return ResponseData.builder().withData(data).withMeta(MetaData.buildException(status)).build();
    }
}
