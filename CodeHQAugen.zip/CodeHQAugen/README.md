# Code HQ Augen API
The starter project defines a simple `/api/ping` resource that can accept `GET` requests with its tests.
Using [Maven](https://maven.apache.org/).
Using [MySQL](https://www.mysql.com/).

Config environment
```bash
DATASOURCE_URL
DATASOURCE_USER
DATASOURCE_PASSWORD
DATASOURCE_DEFAULT_SCHEMA
```

Run build
```bash
$ mvn clean package install

[INFO] BUILD SUCCESS
[INFO] ------------------------------------------------------------------------
[INFO] Total time:  4.805 s
[INFO] Finished at: 2021-11-29T04:16:14+07:00
[INFO] ------------------------------------------------------------------------
```
Using a new shell, you can send a test ping request to your API:
```bash
$ curl -s http://localhost:8080/api/ping

{
    "pong": "Pong!"
}
```